# Something Inspiracion (Forge 1.20.1 · 47.4.1 · GeckoLib 4.4.2)

Port a Java del addon de Bedrock. Mod id: `horror` (mismos ids: `horror:stalker`, etc.).

## Obtener el .jar
**En PC:** instala Java 17 y Gradle 8.x y ejecuta `gradle build`.
El archivo queda en `build/libs/Something_Inspiracion-1.4.1.jar`.

**Desde el celular (sin instalar nada):** sube esta carpeta a un repositorio de GitHub.
En la pestaña *Actions* corre "Compilar mod" y descarga el artefacto `Something_Inspiracion-jar`.

## Instalar
Pon el .jar y `geckolib-forge-1.20.1-4.4.2.jar` en la carpeta `mods` de Forge 1.20.1.

## Estructura del .jar resultante
assets/ · data/ · META-INF/ · com/ · logo.png · pack.mcmeta
