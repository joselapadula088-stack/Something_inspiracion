package com.somethinginspiracion.horror;

import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, HorrorMod.MODID);

    public record Entry(HorrorConfig cfg, RegistryObject<EntityType<HorrorEntity>> type) {}

    public static final Map<String, Entry> ALL = new LinkedHashMap<>();

    public static final Entry STALKER = add(new HorrorConfig("stalker")
            .health(40).size(1.0f, 7f).speed(0.32).damage(6).follow(64).life(180).chase(1.4).wanders());
    public static final Entry SILENT = add(new HorrorConfig("silent")
            .health(30).size(1.0f, 4f).damage(1000).effect(MobEffects.BLINDNESS, 5)
            .voice(ModSounds.LAVENDER).opensDoors().kills(3));
    public static final Entry CRAWLER = add(new HorrorConfig("crawler")
            .health(20).size(1.0f, 4f).harmless());
    public static final Entry TALL_THIN = add(new HorrorConfig("tall_thin")
            .health(60).size(1.6f, 12f).damage(1000).effect(MobEffects.MOVEMENT_SLOWDOWN, 5).kills(4));
    public static final Entry STALKER_HEY = add(new HorrorConfig("stalker_hey")
            .health(35).size(1.5f, 9f).damage(5).effect(MobEffects.MOVEMENT_SLOWDOWN, 5).outsideCap());
    public static final Entry LONG_ARMS = add(new HorrorConfig("long_arms")
            .health(30).size(1.2f, 8f).damage(5).effect(MobEffects.WEAKNESS, 6));
    public static final Entry STALKER_HELLO = add(new HorrorConfig("stalker_hello")
            .health(35).size(1.2f, 10f).damage(5).effect(MobEffects.BLINDNESS, 5).outsideCap());
    public static final Entry SMILER_WATCHER = add(new HorrorConfig("smiler_watcher")
            .health(35).size(1.2f, 10f).damage(5).effect(MobEffects.CONFUSION, 6));
    public static final Entry SOMETHING_LOOKING = add(new HorrorConfig("something_looking")
            .health(25).size(1.2f, 5f).damage(4).effect(MobEffects.MOVEMENT_SLOWDOWN, 5));
    public static final Entry WINDOW_BABY = add(new HorrorConfig("window_baby")
            .health(25).size(1.6f, 12f).damage(1000).effect(MobEffects.CONFUSION, 8)
            .voice(ModSounds.MUDO).kills(4));

    private static Entry add(HorrorConfig c) {
        RegistryObject<EntityType<HorrorEntity>> type = ENTITIES.register(c.name, () ->
                EntityType.Builder.<HorrorEntity>of((t, level) -> new HorrorEntity(t, level, c), MobCategory.MONSTER)
                        .sized(c.width, c.height)
                        .clientTrackingRange(10)
                        .build(HorrorMod.MODID + ":" + c.name));
        Entry e = new Entry(c, type);
        ALL.put(c.name, e);
        return e;
    }

    private ModEntities() {}
}
