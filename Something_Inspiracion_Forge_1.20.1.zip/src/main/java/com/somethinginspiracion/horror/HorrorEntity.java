package com.somethinginspiracion.horror;

import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.game.ClientboundStopSoundPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.BreakDoorGoal;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.OpenDoorGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.navigation.GroundPathNavigation;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.registries.RegistryObject;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.util.GeckoLibUtil;

/**
 * Entidad de terror genérica. Cada tipo (stalker, silent, etc.) cambia solo su HorrorConfig.
 */
public class HorrorEntity extends PathfinderMob implements GeoEntity {
    private static final RawAnimation IDLE = RawAnimation.begin().thenLoop("animation.horror.idle");
    private static final int AMBIENCE_PERIOD = 790; // 39.5 s, como la animación de Bedrock
    private static final int AMBIENCE_OFFSET = 60;  // suena a los 3.0 s

    private final HorrorConfig cfg;
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private int life = 0;
    private int vanishTicks = -1;
    private boolean announced = false;

    public HorrorEntity(EntityType<? extends HorrorEntity> type, Level level, HorrorConfig cfg) {
        super(type, level);
        this.cfg = cfg;
        this.xpReward = 0;
        this.setPersistenceRequired();
        initGoals();
    }

    public HorrorConfig cfg() { return cfg; }

    public static AttributeSupplier.Builder attributes(HorrorConfig c) {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, c.health)
                .add(Attributes.MOVEMENT_SPEED, c.speed)
                .add(Attributes.ATTACK_DAMAGE, c.damage)
                .add(Attributes.FOLLOW_RANGE, c.follow);
    }

    /** Se deja vacío: Mob lo llama antes de que exista cfg. Usamos initGoals(). */
    @Override
    protected void registerGoals() {}

    private void initGoals() {
        if (this.level().isClientSide) return;
        if (this.getNavigation() instanceof GroundPathNavigation nav) {
            nav.setCanOpenDoors(true);
        }
        this.goalSelector.addGoal(0, new FloatGoal(this));
        if (cfg.attacks) {
            if (cfg.opensDoors) this.goalSelector.addGoal(3, new OpenDoorGoal(this, false));
            this.goalSelector.addGoal(4, new BreakDoorGoal(this, d -> true));
            this.goalSelector.addGoal(2, new MeleeAttackGoal(this, cfg.chase, true));
            this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
            this.targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(this, Player.class, 10, false, false, null));
        }
        if (cfg.wanders) this.goalSelector.addGoal(6, new WaterAvoidingRandomStrollGoal(this, 1.0));
        this.goalSelector.addGoal(7, new LookAtPlayerGoal(this, Player.class, 16.0F));
        this.goalSelector.addGoal(8, new RandomLookAroundGoal(this));
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        // Si un jugador le pega, desaparece sin recibir daño (damage_sensor de Bedrock).
        if (source.getEntity() instanceof Player) {
            if (!this.level().isClientSide) vanish();
            return false;
        }
        return super.hurt(source, amount);
    }

    public void vanish() {
        if (vanishTicks != -1) return;
        vanishTicks = 6; // 0.3 s
        if (this.level() instanceof ServerLevel sl) {
            List<RegistryObject<SoundEvent>> stops = List.of(
                    ModSounds.SLIP_AMBIENCE, ModSounds.MUDO, ModSounds.LAVENDER, ModSounds.STALKER_VOICE);
            for (ServerPlayer p : sl.players()) {
                for (RegistryObject<SoundEvent> s : stops) {
                    p.connection.send(new ClientboundStopSoundPacket(s.getId(), null));
                }
            }
            sl.playSound(null, this.getX(), this.getY(), this.getZ(), ModSounds.SIREN.get(), SoundSource.NEUTRAL, 3.0F, 1.0F);
        }
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide) return;
        if (vanishTicks > 0) {
            if (--vanishTicks == 0) this.discard();
            return;
        }
        if (!announced) {
            announced = true;
            this.level().playSound(null, this.getX(), this.getY(), this.getZ(), cfg.voice.get(), SoundSource.HOSTILE, 4.0F, 1.0F);
        }
        life++;
        if (life >= cfg.lifeSeconds * 20) {
            vanish();
            return;
        }
        if (life % AMBIENCE_PERIOD == AMBIENCE_OFFSET) {
            this.level().playSound(null, this.getX(), this.getY(), this.getZ(), ModSounds.SLIP_AMBIENCE.get(), SoundSource.AMBIENT, 2.0F, 1.0F);
        }
    }

    @Override
    public boolean doHurtTarget(Entity target) {
        boolean hit = super.doHurtTarget(target);
        if (hit && cfg.effect != null && target instanceof LivingEntity living) {
            living.addEffect(new MobEffectInstance(cfg.effect, cfg.effectSeconds * 20));
        }
        return hit;
    }

    @Override
    protected void playStepSound(BlockPos pos, BlockState state) {}

    @Override
    public boolean removeWhenFarAway(double distanceSqr) { return false; }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("HorrorLife", life);
        tag.putBoolean("HorrorAnnounced", announced);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        life = tag.getInt("HorrorLife");
        announced = tag.getBoolean("HorrorAnnounced");
    }

    // ---- GeckoLib ----
    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "idle", 0, state -> state.setAndContinue(IDLE)));
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() { return cache; }
}
