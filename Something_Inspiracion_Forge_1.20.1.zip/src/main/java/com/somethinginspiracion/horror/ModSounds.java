package com.somethinginspiracion.horror;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public final class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(Registries.SOUND_EVENT, HorrorMod.MODID);

    public static final RegistryObject<SoundEvent> SIREN = reg("horror.siren");
    public static final RegistryObject<SoundEvent> STALKER_VOICE = reg("horror.stalker_voice");
    public static final RegistryObject<SoundEvent> LAVENDER = reg("horror.lavender");
    public static final RegistryObject<SoundEvent> MUDO = reg("horror.mudo");
    public static final RegistryObject<SoundEvent> SLIP_AMBIENCE = reg("horror.slip_ambience");

    private static RegistryObject<SoundEvent> reg(String name) {
        return SOUNDS.register(name, () ->
                SoundEvent.createVariableRangeEvent(new ResourceLocation(HorrorMod.MODID, name)));
    }

    private ModSounds() {}
}
