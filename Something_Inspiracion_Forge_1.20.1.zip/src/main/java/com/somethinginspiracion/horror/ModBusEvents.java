package com.somethinginspiracion.horror;

import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = HorrorMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class ModBusEvents {
    @SubscribeEvent
    public static void onAttributes(EntityAttributeCreationEvent event) {
        for (ModEntities.Entry e : ModEntities.ALL.values()) {
            event.put(e.type().get(), HorrorEntity.attributes(e.cfg()).build());
        }
    }

    private ModBusEvents() {}
}
