package com.somethinginspiracion.horror;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public final class ModTabs {
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, HorrorMod.MODID);

    public static final RegistryObject<CreativeModeTab> MAIN = TABS.register("main", () ->
            CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.horror"))
                    .icon(() -> new ItemStack(ModItems.FLASHLIGHT.get()))
                    .displayItems((params, out) -> {
                        out.accept(ModItems.FLASHLIGHT.get());
                        ModItems.EGGS.forEach(r -> out.accept(r.get()));
                    })
                    .build());

    private ModTabs() {}
}
