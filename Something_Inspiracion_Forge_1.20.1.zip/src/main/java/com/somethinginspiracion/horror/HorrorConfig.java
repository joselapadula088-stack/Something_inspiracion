package com.somethinginspiracion.horror;

import java.util.function.Supplier;
import javax.annotation.Nullable;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.effect.MobEffect;

/** Parámetros de cada entidad (equivalente a los components del JSON de Bedrock). */
public class HorrorConfig {
    public final String name;
    public double health = 20;
    public float width = 1.0f;
    public float height = 2.0f;
    public double speed = 0;
    public double damage = 0;
    @Nullable public MobEffect effect = null;
    public int effectSeconds = 0;
    public double follow = 48;
    public int lifeSeconds = 120;
    public Supplier<SoundEvent> voice = ModSounds.STALKER_VOICE;
    public boolean attacks = true;
    public boolean wanders = false;
    public double chase = 1.2;
    public boolean opensDoors = false;
    public double killDistance = 0;
    public boolean countsInCap = true;

    public HorrorConfig(String name) { this.name = name; }

    public HorrorConfig health(double v) { health = v; return this; }
    public HorrorConfig size(float w, float h) { width = w; height = h; return this; }
    public HorrorConfig speed(double v) { speed = v; return this; }
    public HorrorConfig damage(double v) { damage = v; return this; }
    public HorrorConfig effect(MobEffect e, int seconds) { effect = e; effectSeconds = seconds; return this; }
    public HorrorConfig follow(double v) { follow = v; return this; }
    public HorrorConfig life(int seconds) { lifeSeconds = seconds; return this; }
    public HorrorConfig voice(Supplier<SoundEvent> s) { voice = s; return this; }
    public HorrorConfig harmless() { attacks = false; countsInCap = false; return this; }
    public HorrorConfig wanders() { wanders = true; return this; }
    public HorrorConfig chase(double v) { chase = v; return this; }
    public HorrorConfig opensDoors() { opensDoors = true; return this; }
    public HorrorConfig kills(double dist) { killDistance = dist; return this; }
    public HorrorConfig outsideCap() { countsInCap = false; return this; }
}
