package com.somethinginspiracion.horror;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStartingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Port del scripts/main.js del addon de Bedrock. */
@Mod.EventBusSubscriber(modid = HorrorMod.MODID)
public final class GameEvents {
    private static final String FLASHLIGHT_KEY = "horror_linterna";
    private static final int MAX_EN_MUNDO = 8;
    private static final int RADIO_PUERTAS = 20;
    private static final String[] ALEATORIAS = {
            "stalker", "tall_thin", "window_baby", "long_arms", "smiler_watcher", "something_looking" };
    private static final String[] PROTEGIDOS = {
            "bedrock", "barrier", "command_block", "structure_block", "end_portal", "chest", "barrel",
            "shulker_box", "furnace", "smoker", "hopper", "dispenser", "dropper", "brewing_stand" };
    private static final int[][] DIRS = { {1, 0}, {-1, 0}, {0, 1}, {0, -1} };

    private static long ticks = 0;

    @SubscribeEvent
    public static void onServerStarting(ServerStartingEvent e) { ticks = 0; }

    @SubscribeEvent
    public static void onClone(PlayerEvent.Clone e) {
        if (e.getOriginal().getPersistentData().getBoolean(FLASHLIGHT_KEY)) {
            e.getEntity().getPersistentData().putBoolean(FLASHLIGHT_KEY, true);
        }
    }

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        MinecraftServer server = e.getServer();
        ticks++;
        List<ServerPlayer> players = new ArrayList<>(server.getPlayerList().getPlayers());
        if (players.isEmpty()) return;

        if (ticks % 4 == 0) killers(players);
        if (ticks % 10 == 0) flashlightVision(players);
        if (ticks % 20 == 0) giveFlashlight(players);
        if (ticks % 6000 == 0) randomAndSilent(players);            // cada 5 min
        if (ticks % 1200 == 0) periodic("crawler", 6, players);     // cada 1 min
        if (ticks % 10800 == 0) periodic("stalker_hey", 3, players); // cada 9 min
        if (ticks >= 4800 && (ticks - 4800) % 10800 == 0) periodic("stalker_hello", 3, players); // desfasado 4 min
    }

    // ---------- Muerte por cercanía ----------
    private static void killers(List<ServerPlayer> players) {
        for (ServerPlayer p : players) {
            try {
                if (p.isCreative() || p.isSpectator() || !p.isAlive()) continue;
                ServerLevel level = p.serverLevel();
                List<HorrorEntity> near = level.getEntitiesOfClass(HorrorEntity.class, p.getBoundingBox().inflate(6.0));
                for (HorrorEntity h : near) {
                    double d = h.cfg().killDistance;
                    if (d > 0 && h.isAlive() && h.position().distanceTo(p.position()) <= d) {
                        p.kill();
                        break;
                    }
                }
            } catch (Exception ignored) {}
        }
    }

    // ---------- Linterna ----------
    private static void giveFlashlight(List<ServerPlayer> players) {
        for (ServerPlayer p : players) {
            try {
                CompoundTag data = p.getPersistentData();
                if (data.getBoolean(FLASHLIGHT_KEY)) continue;
                if (p.getInventory().add(new ItemStack(ModItems.FLASHLIGHT.get()))) {
                    data.putBoolean(FLASHLIGHT_KEY, true);
                }
            } catch (Exception ignored) {}
        }
    }

    private static void flashlightVision(List<ServerPlayer> players) {
        for (ServerPlayer p : players) {
            if (p.getMainHandItem().is(ModItems.FLASHLIGHT.get())) {
                p.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 260, 0, false, false, false));
            }
        }
    }

    // ---------- Apariciones ----------
    private static int countCap(ServerLevel level) {
        int n = 0;
        for (Entity en : level.getAllEntities()) {
            if (en instanceof HorrorEntity h && h.cfg().countsInCap) n++;
        }
        return n;
    }

    private static void randomAndSilent(List<ServerPlayer> players) {
        for (ServerPlayer p : players) {
            ServerLevel level = p.serverLevel();
            if (level.dimension() != Level.OVERWORLD) continue;
            try {
                if (countCap(level) < MAX_EN_MUNDO) {
                    spawnRandom(p, level, ALEATORIAS[level.random.nextInt(ALEATORIAS.length)]);
                }
            } catch (Exception ignored) {}
            try {
                if (countCap(level) < MAX_EN_MUNDO) silentAtDoor(p, level);
            } catch (Exception ignored) {}
        }
    }

    private static void periodic(String name, int max, List<ServerPlayer> players) {
        for (ServerPlayer p : players) {
            try {
                ServerLevel level = p.serverLevel();
                if (level.dimension() != Level.OVERWORLD) continue;
                List<HorrorEntity> existing = new ArrayList<>();
                for (Entity en : level.getAllEntities()) {
                    if (en instanceof HorrorEntity h && h.cfg().name.equals(name)) existing.add(h);
                }
                if (existing.size() >= max) existing.get(0).discard();
                spawnRandom(p, level, name);
            } catch (Exception ignored) {}
        }
    }

    private static void spawnRandom(ServerPlayer p, ServerLevel level, String name) {
        double ang = level.random.nextDouble() * Math.PI * 2;
        double dist = 20 + level.random.nextDouble() * 12;
        int x = Mth.floor(p.getX() + Math.cos(ang) * dist);
        int z = Mth.floor(p.getZ() + Math.sin(ang) * dist);
        if (!level.hasChunkAt(new BlockPos(x, p.getBlockY(), z))) return;
        int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
        HorrorEntity ent = ModEntities.ALL.get(name).type().get().create(level);
        if (ent == null) return;
        ent.moveTo(x + 0.5, y, z + 0.5, level.random.nextFloat() * 360F, 0F);
        level.addFreshEntity(ent);
    }

    // ---------- Silent frente a una puerta ----------
    private static boolean isLowerDoor(ServerLevel level, BlockPos pos) {
        BlockState s = level.getBlockState(pos);
        return s.getBlock() instanceof DoorBlock && s.getValue(DoorBlock.HALF) == DoubleBlockHalf.LOWER;
    }

    private static List<BlockPos> findDoors(ServerPlayer p, ServerLevel level) {
        List<BlockPos> doors = new ArrayList<>();
        BlockPos o = p.blockPosition();
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        for (int dx = -RADIO_PUERTAS; dx <= RADIO_PUERTAS; dx++) {
            for (int dz = -RADIO_PUERTAS; dz <= RADIO_PUERTAS; dz++) {
                for (int dy = -5; dy <= 5; dy++) {
                    m.set(o.getX() + dx, o.getY() + dy, o.getZ() + dz);
                    if (!level.hasChunkAt(m)) continue;
                    if (isLowerDoor(level, m)) doors.add(m.immutable());
                }
            }
        }
        return doors;
    }

    private static boolean silentAtDoor(ServerPlayer p, ServerLevel level) {
        List<BlockPos> doors = findDoors(p, level);
        if (doors.isEmpty()) return false;
        BlockPos door = doors.get(level.random.nextInt(doors.size()));
        List<int[]> dirs = new ArrayList<>(List.of(DIRS));
        Collections.shuffle(dirs, new java.util.Random(level.random.nextLong()));

        for (int dist : new int[] {2, 1}) {
            for (int[] d : dirs) {
                int x = door.getX() + d[0] * dist, z = door.getZ() + d[1] * dist, y = door.getY();
                BlockPos feet = new BlockPos(x, y, z);
                if (!level.hasChunkAt(feet)) continue;
                if (level.getBlockState(feet).isAir()
                        && level.getBlockState(feet.above()).isAir()
                        && !level.getBlockState(feet.below()).isAir()) {
                    HorrorEntity silent = ModEntities.SILENT.type().get().create(level);
                    if (silent == null) return false;
                    double dxs = (door.getX() + 0.5) - (x + 0.5), dzs = (door.getZ() + 0.5) - (z + 0.5);
                    float yaw = (float) (Mth.atan2(dzs, dxs) * 57.2957795) - 90.0F;
                    silent.moveTo(x + 0.5, y, z + 0.5, yaw, 0F);
                    silent.setYHeadRot(yaw);
                    silent.setYBodyRot(yaw);
                    despejar(level, x, y, z, -d[0], -d[1], dist);
                    level.addFreshEntity(silent);
                    BlockState ds = level.getBlockState(door);
                    if (ds.getBlock() instanceof DoorBlock db) db.setOpen(null, level, ds, door, true);
                    return true;
                }
            }
        }
        return false;
    }

    /** Rompe los bloques que tapan el cuerpo, cuello y cabeza del Silent. */
    private static void despejar(ServerLevel level, int x, int y, int z, int dx, int dz, int dist) {
        boolean ejeX = dx == 0;
        int[] profundidades = dist == 2 ? new int[] {0, 1} : new int[] {0};
        for (int t = -3; t <= 3; t++) {
            for (int h = 0; h <= 4; h++) {
                for (int f : profundidades) {
                    int bx = x + (ejeX ? t : 0) + (dx == 0 ? 0 : dx * f);
                    int bz = z + (ejeX ? 0 : t) + (dz == 0 ? 0 : dz * f);
                    BlockPos pos = new BlockPos(bx, y + h, bz);
                    if (!level.hasChunkAt(pos)) continue;
                    BlockState st = level.getBlockState(pos);
                    if (st.isAir() || !st.getFluidState().isEmpty() || st.getBlock() instanceof DoorBlock) continue;
                    if (st.getDestroySpeed(level, pos) < 0) continue;
                    if (protegido(st.getBlock())) continue;
                    level.destroyBlock(pos, true);
                }
            }
        }
    }

    private static boolean protegido(Block b) {
        String path = BuiltInRegistries.BLOCK.getKey(b).getPath();
        for (String s : PROTEGIDOS) if (path.contains(s)) return true;
        return false;
    }

    private GameEvents() {}
}
