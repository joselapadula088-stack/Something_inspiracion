package com.somethinginspiracion.horror;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.world.item.Item;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, HorrorMod.MODID);

    public static final RegistryObject<Item> FLASHLIGHT =
            ITEMS.register("flashlight", () -> new Item(new Item.Properties().stacksTo(1)));

    public static final List<RegistryObject<Item>> EGGS = new ArrayList<>();

    static {
        for (ModEntities.Entry e : ModEntities.ALL.values()) {
            EGGS.add(ITEMS.register(e.cfg().name + "_spawn_egg",
                    () -> new ForgeSpawnEggItem(e.type(), 0x1A1A1A, 0x8B0000, new Item.Properties())));
        }
    }

    private ModItems() {}
}
