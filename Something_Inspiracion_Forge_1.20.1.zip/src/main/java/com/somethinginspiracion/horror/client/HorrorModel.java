package com.somethinginspiracion.horror.client;

import com.somethinginspiracion.horror.HorrorEntity;
import com.somethinginspiracion.horror.HorrorMod;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;

public class HorrorModel extends GeoModel<HorrorEntity> {
    @Override
    public ResourceLocation getModelResource(HorrorEntity e) {
        return new ResourceLocation(HorrorMod.MODID, "geo/" + e.cfg().name + ".geo.json");
    }

    @Override
    public ResourceLocation getTextureResource(HorrorEntity e) {
        return new ResourceLocation(HorrorMod.MODID, "textures/entity/" + e.cfg().name + ".png");
    }

    @Override
    public ResourceLocation getAnimationResource(HorrorEntity e) {
        return new ResourceLocation(HorrorMod.MODID, "animations/" + e.cfg().name + ".animation.json");
    }
}
