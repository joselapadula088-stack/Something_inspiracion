package com.somethinginspiracion.horror.client;

import com.somethinginspiracion.horror.HorrorEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

public class HorrorRenderer extends GeoEntityRenderer<HorrorEntity> {
    public HorrorRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new HorrorModel());
        this.shadowRadius = 0.0F;
    }
}
