package com.somethinginspiracion.horror.client;

import com.somethinginspiracion.horror.HorrorMod;
import com.somethinginspiracion.horror.ModEntities;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = HorrorMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientSetup {
    @SubscribeEvent
    public static void onRenderers(EntityRenderersEvent.RegisterRenderers event) {
        for (ModEntities.Entry e : ModEntities.ALL.values()) {
            event.registerEntityRenderer(e.type().get(), HorrorRenderer::new);
        }
    }

    private ClientSetup() {}
}
